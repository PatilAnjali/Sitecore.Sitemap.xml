﻿namespace LD.Sitemap.Xml.Events
{
    /// <summary>
    /// Remote event for Event Queue
    /// </summary>
    public class BuildSitemapRemoteEvent
    {
    }
}
