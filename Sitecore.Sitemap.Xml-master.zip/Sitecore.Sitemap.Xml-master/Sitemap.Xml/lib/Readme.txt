﻿In this directory, you should add:

Sitecore.Kernel.dll
Sitecore.ContentSearch.dll
Sitecore.ContentSearch.Linq.dll